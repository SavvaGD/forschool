r = int(input())
k = int(input())
p = int(input())
s = int(input())

psk = k * p
ok = s - psk
x = ok // (r + 1)

print(x)