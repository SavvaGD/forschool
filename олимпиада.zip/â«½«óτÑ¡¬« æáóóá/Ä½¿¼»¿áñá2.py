n = 9
h = 6
d = 2

print(n * (h + 1) + (d * (n - 1)))