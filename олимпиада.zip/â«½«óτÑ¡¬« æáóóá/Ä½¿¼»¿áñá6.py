import sys

input_data = sys.stdin.read().split()
if input_data:
    n = int(input_data[0])
    t = int(input_data[1])
    ks = sorted(int(x) for x in input_data[2:2+n])

    v = 0
    p2 = 0
    p3 = 0

    for p1 in range(n):
        # Ищем первый элемент k2, такой что k2 - k1 >= t
        while p2 < n and ks[p2] < ks[p1] + t:
            p2 += 1
            
        # Ищем первый элемент k3, такой что k3 - k1 > t
        while p3 < n and ks[p3] <= ks[p1] + t:
            p3 += 1
            
        # Количество подходящих k2 (которые строго больше k1, но разность меньше t)
        # Это элементы на полуинтервале от (p1 + 1) до p2
        count_k2 = max(0, p2 - (p1 + 1))
        
        # Количество подходящих k3 (которые строго больше k1 + t)
        count_k3 = n - p3
        
        v += count_k2 * count_k3

    print(v)