year = ["01", "01", "2012"]
ck = 0

while True:
    # 1. Проверяем текущую дату. Если дошли до финиша — считаем её последней и выходим
    if year == ["31", "12", "2013"]:
        nums = [0, 0, 0, 0, 0, 0, 0, 0]
        for i in range(2): nums[i] = year[0][i]
        for i in range(2): nums[i + 2] = year[1][i]
        for i in range(4): nums[i + 4] = year[2][i]
        numc = {}
        for num in range(8):
            numc[nums[num]] = numc.get(nums[num], 0) + 1
        vals = list(numc.values())
        if vals and all(v == vals[0] for v in vals):
            ck += 1
        break # Останавливаем цикл
        
    # 2. Выделяем цифры из текущей даты
    nums = [0, 0, 0, 0, 0, 0, 0, 0]
    numc = {}
    for i in range(2):
        nums[i] = year[0][i]
    for i in range(2):
        nums[i + 2] = year[1][i]
    for i in range(4):
        nums[i + 4] = year[2][i]
    
    # 3. Считаем количество каждой цифры
    for num in range(8):
        current_digit = nums[num]
        if current_digit in numc:
            numc[current_digit] += 1
        else:
            numc[current_digit] = 1

    # 4. Проверяем, равны ли счётчики
    vals = list(numc.values())
    if vals and all(v == vals[0] for v in vals):
        ck += 1
    
    # 5. ПРАВИЛЬНЫЙ И БЕЗОПАСНЫЙ ПЕРЕХОД НА СЛЕДУЮЩИЙ ДЕНЬ
    d = int(year[0])
    m = int(year[1])
    y = int(year[2])
    
    # Проверка на високосный год для февраля
    is_leap = (y % 4 == 0 and y % 100 != 0) or (y % 400 == 0)
    days_in_months = [0, 31, 29 if is_leap else 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
    
    d += 1 # Шаг вперёд на один день
    if d > days_in_months[m]:
        d = 1
        m += 1
        if m > 12:
            m = 1
            y += 1
            
    # Сохраняем новые значения обратно в список строк
    year[0] = f"{d:02d}"
    year[1] = f"{m:02d}"
    year[2] = str(y)
        
# Этот принт сработает сразу, как только цикл завершится
print("Ответ:", ck)
