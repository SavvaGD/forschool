x1 = int(input())
y1 = int(input())
x2 = int(input())
y2 = int(input())
x3 = int(input())
y3 = int(input())
x4 = int(input())
y4 = int(input())

left1 = min(x1, x2)
right1 = max(x1, x2)
bottom1 = min(y1, y2)
top1 = max(y1, y2)

left2 = min(x3, x4)
right2 = max(x3, x4)
bottom2 = min(y3, y4)
top2 = max(y3, y4)

left2 = min(x3, x4)
right2 = max(x3, x4)
bottom2 = min(y3, y4)
top2 = max(y3, y4)

inter_left = max(left1, left2)
inter_right = min(right1, right2)
inter_bottom = max(bottom1, bottom2)
inter_top = min(top1, top2)

width = inter_right - inter_left
height = inter_top - inter_bottom

sq = width * height

print(sq)