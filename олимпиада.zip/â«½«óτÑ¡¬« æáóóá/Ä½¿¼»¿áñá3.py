num = "00000"
numn = 38205
while True:
    res = int(num) + int(num[1] + num[2] + num[3] + num[4]) + int(num[2] + num[3] + num[4]) + int(num[3] + num[4]) + int(num[4])
    if res == numn:
        print(num)
    if num == "99999":
        break
    num = f"{int(num) + 1:05d}"